# ui-testing-xctest-uiwebview

This project shows an issue with entering data in a textfield in a UIWebView using UI Testing in Xcode (xctest). 

If you know how to fix this please create a pull request.
